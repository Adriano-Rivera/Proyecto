﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa
{
    public partial class CrearTorneo : Form
    {
        private GestionAtletas gestionAtletas;
        private List<TextBox> fixtureExtremos;
        private HashSet<TextBox> ocupados;
        public CrearTorneo()
        {

            InitializeComponent();

            checkBox1.CheckedChanged += CheckBox_CheckedChanged;
            checkBox2.CheckedChanged += CheckBox_CheckedChanged;
            checkBox3.CheckedChanged += CheckBox_CheckedChanged;
            checkBox4.CheckedChanged += CheckBox_CheckedChanged;

            checkBox11.CheckedChanged += CheckBox_CheckedChanged;
            checkBox12.CheckedChanged += CheckBox_CheckedChanged;
            checkBox13.CheckedChanged += CheckBox_CheckedChanged;
            checkBox14.CheckedChanged += CheckBox_CheckedChanged;

            checkBox5.CheckedChanged += CheckBox_CheckedChanged;
            checkBox6.CheckedChanged += CheckBox_CheckedChanged;
            checkBox7.CheckedChanged += CheckBox_CheckedChanged;
            checkBox8.CheckedChanged += CheckBox_CheckedChanged;
            checkBox9.CheckedChanged += CheckBox_CheckedChanged;
            checkBox10.CheckedChanged += CheckBox_CheckedChanged;

            fixtureExtremos = new List<TextBox> { textBox1, textBox2, textBox3, textBox4, textBox11, textBox12, textBox13, textBox14 };

            ocupados = new HashSet<TextBox>();

            gestionAtletas = new GestionAtletas();
            CargarAtletasEnComboBox();
        }

        private void CargarAtletasEnComboBox()
        {
           
            List<string> nombresAtletas = gestionAtletas.ObtenerNombresDeAtletas();
            comboBoxAtletas.Items.Clear(); // Asegúrate de limpiar los items anteriores
            comboBoxAtletas.Items.AddRange(nombresAtletas.ToArray());
        }
    

    private void AgregarTorneos_Load(object sender, EventArgs e)
        {

        }

        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {

            if (sender is CheckBox checkBox)
            {
                // Verificación de los CheckBox para asegurarse de que no estén marcados si la TextBox correspondiente está vacía
                if (checkBox == checkBox5 && string.IsNullOrWhiteSpace(textBox6.Text))
                {
                    checkBox.Checked = false; // Desmarcar checkBox5 si textBox6 está vacía
                    MessageBox.Show("Falta contrincante");
                    return;
                }
                else if (checkBox == checkBox6 && string.IsNullOrWhiteSpace(textBox5.Text))
                {
                    checkBox.Checked = false; // Desmarcar checkBox6 si textBox5 está vacía
                    MessageBox.Show("Falta contrincante");
                    return;
                }
                else if (checkBox == checkBox9 && string.IsNullOrWhiteSpace(textBox10.Text))
                {
                    checkBox.Checked = false; // Desmarcar checkBox9 si textBox10 está vacía
                    MessageBox.Show("Falta contrincante");
                    return;
                }
                else if (checkBox == checkBox10 && string.IsNullOrWhiteSpace(textBox9.Text))
                {
                    checkBox.Checked = false; // Desmarcar checkBox10 si textBox9 está vacía
                    MessageBox.Show("Falta contrincante");
                    return;
                }

                // Verificación de los CheckBox de textBox1 y textBox2 para evitar marcar sin contrincante
                if (checkBox == checkBox1 && string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    checkBox.Checked = false; // Desmarcar checkBox1 si textBox2 está vacía
                    MessageBox.Show("Falta contrincante");
                    return;
                }
                else if (checkBox == checkBox2 && string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    checkBox.Checked = false; // Desmarcar checkBox2 si textBox1 está vacía
                    MessageBox.Show("Falta contrincante");
                    return;
                }
                else if (checkBox == checkBox3 && string.IsNullOrWhiteSpace(textBox4.Text))
                {
                    checkBox.Checked = false; // Desmarcar checkBox3 si textBox4 está vacía
                    MessageBox.Show("Falta contrincante");
                    return;
                }
                else if (checkBox == checkBox4 && string.IsNullOrWhiteSpace(textBox3.Text))
                {
                    checkBox.Checked = false; // Desmarcar checkBox4 si textBox3 está vacía
                    MessageBox.Show("Falta contrincante");
                    return;
                }

                // Verificación de los CheckBox de textBox13 y textBox14 para evitar marcar sin contrincante
                if (checkBox == checkBox14 && string.IsNullOrWhiteSpace(textBox13.Text))
                {
                    checkBox.Checked = false; // Desmarcar checkBox14 si textBox13 está vacía
                    MessageBox.Show("Falta contrincante");
                    return;
                }
                else if (checkBox == checkBox12 && string.IsNullOrWhiteSpace(textBox14.Text))
                {
                    checkBox.Checked = false; // Desmarcar checkBox12 si textBox14 está vacía
                    MessageBox.Show("Falta contrincante");
                    return;
                }
                else if (checkBox == checkBox11 && string.IsNullOrWhiteSpace(textBox10.Text))
                {
                    checkBox.Checked = false; // Desmarcar checkBox11 si textBox10 está vacía
                    MessageBox.Show("Falta contrincante");
                    return;
                }
                else if (checkBox == checkBox10 && string.IsNullOrWhiteSpace(textBox11.Text))
                {
                    checkBox.Checked = false; // Desmarcar checkBox10 si textBox11 está vacía
                    MessageBox.Show("Falta contrincante");
                    return;
                }
                else if (checkBox == checkBox7 && string.IsNullOrWhiteSpace(textBox8.Text))
                {
                    checkBox.Checked = false; // Desmarcar checkBox10 si textBox11 está vacía
                    MessageBox.Show("Falta contrincante");
                    return;
                }
                else if (checkBox == checkBox8 && string.IsNullOrWhiteSpace(textBox7.Text))
                {
                    checkBox.Checked = false; // Desmarcar checkBox10 si textBox11 está vacía
                    MessageBox.Show("Falta contrincante");
                    return;
                }
            }


            // Verificar cuál CheckBox fue marcado
            if (sender == checkBox1)
            {
                // Si checkBox1 está marcado, mover el texto de textBox1 a textBox5
                if (checkBox1.Checked)
                {
                    textBox5.Text = textBox1.Text;
                    checkBox1.Checked = false; // Desmarcar checkBox3 después de mover el texto
                }
            }
            else if (sender == checkBox2)
            {
                // Si checkBox2 está marcado, mover el texto de textBox2 a textBox5
                if (checkBox2.Checked)
                {
                    textBox5.Text = textBox2.Text;
                    checkBox2.Checked = false; // Desmarcar checkBox3 después de mover el texto
                }
            }
            else if (sender == checkBox3)
            {
                // Si checkBox3 está marcado, mover el texto de textBox3 a textBox6
                if (checkBox3.Checked)
                {
                    textBox6.Text = textBox3.Text;
                    checkBox3.Checked = false; // Desmarcar checkBox3 después de mover el texto
                }
            }
            else if (sender == checkBox4)
            {
                // Si checkBox4 está marcado, mover el texto de textBox4 a textBox6
                if (checkBox4.Checked)
                {
                    textBox6.Text = textBox4.Text;

                }
                checkBox4.Checked = false; // Desmarcar checkBox3 después de mover el texto
            }

            else if (sender == checkBox11)
            {
                // Si checkBox11 está marcado, mover el texto de textBox11 a textBox10
                if (checkBox11.Checked)
                {
                    textBox10.Text = textBox11.Text;
                    // No limpiar textBox11 para que el texto no se borre
                    checkBox11.Checked = false; // Desmarcar checkBox11 después de mover el texto
                }
            }
            else if (sender == checkBox12)
            {
                // Si checkBox12 está marcado, mover el texto de textBox12 a textBox10
                if (checkBox12.Checked)
                {
                    textBox10.Text = textBox12.Text;
                    // No limpiar textBox12 para que el texto no se borre
                    checkBox12.Checked = false; // Desmarcar checkBox12 después de mover el texto
                }
            }
            else if (sender == checkBox13)
            {
                // Si checkBox13 está marcado, mover el texto de textBox13 a textBox9
                if (checkBox13.Checked)
                {
                    textBox9.Text = textBox13.Text;
                    // No limpiar textBox13 para que el texto no se borre
                    checkBox13.Checked = false; // Desmarcar checkBox13 después de mover el texto
                }
            }
            else if (sender == checkBox14)
            {
                // Si checkBox14 está marcado, mover el texto de textBox14 a textBox9
                if (checkBox14.Checked)
                {
                    textBox9.Text = textBox14.Text;
                    // No limpiar textBox14 para que el texto no se borre
                    checkBox14.Checked = false; // Desmarcar checkBox14 después de mover el texto
                }
            }
            else if (sender == checkBox5)
            {
                
                if (checkBox5.Checked)
                {
                    textBox7.Text = textBox5.Text;
                   
                    checkBox5.Checked = false; 
                }
            }
            else if (sender == checkBox6)
            {

                if (checkBox6.Checked)
                {
                    textBox7.Text = textBox6.Text;

                    checkBox6.Checked = false;
                }
            }
            else if (sender == checkBox9)
            {

                if (checkBox9.Checked)
                {
                    textBox8.Text = textBox9.Text;

                    checkBox9.Checked = false;
                }
            }
            else if (sender == checkBox10)
            {

                if (checkBox10.Checked) 
                {
                    textBox8.Text = textBox10.Text;

                    checkBox10.Checked = false;
                }
            }
            else if (sender == checkBox7)
            {

                if (checkBox7.Checked)
                {
                    string Ganador = textBox7.Text;
                    MessageBox.Show("Ganador del torneo "+ Ganador);

                    checkBox7.Checked = false;
                }
            }
            else if (sender == checkBox8)
            {

                if (checkBox8.Checked)
                {
                    string Ganador = textBox8.Text;
                    MessageBox.Show("Ganador del torneo " + Ganador);

                    checkBox7.Checked = false;
                }
            }
        }
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            // Verificar si se ha seleccionado un atleta en el ComboBox
            if (comboBoxAtletas.SelectedItem != null)
            {
                string nombreAtleta = comboBoxAtletas.SelectedItem.ToString();

                // Seleccionar aleatoriamente uno de los TextBox extremos que no esté ocupado
                Random random = new Random();
                TextBox textBoxSeleccionado = null;

                // Intentar encontrar un TextBox no ocupado
                for (int i = 0; i < fixtureExtremos.Count; i++)
                {
                    int indice = random.Next(fixtureExtremos.Count);
                    textBoxSeleccionado = fixtureExtremos[indice];

                    // Si el TextBox no está ocupado, lo seleccionamos
                    if (!ocupados.Contains(textBoxSeleccionado))
                    {
                        break;
                    }
                    // Si todos los TextBox están ocupados, mostrar un mensaje
                    if (i == fixtureExtremos.Count - 1)
                    {
                        MessageBox.Show("Todas las posiciones ya estan ocupadas.");
                        return;
                    }
                }

                // Asignar el nombre del atleta al TextBox seleccionado
                textBoxSeleccionado.Text = nombreAtleta;
                ocupados.Add(textBoxSeleccionado); // Marcar como ocupado
            }
            else
            {
                MessageBox.Show("Por favor, seleccione un atleta.");
            }
        }

        private void comboBoxAtletas_KeyDown(object sender, KeyEventArgs e)
        {
            // Verifica si se presionó la tecla Enter
            if (e.KeyCode == Keys.Enter)
            {
                // Verificar si se ha seleccionado un atleta en el ComboBox
                if (comboBoxAtletas.SelectedItem != null)
                {
                    string nombreAtleta = comboBoxAtletas.SelectedItem.ToString();

                    // Seleccionar aleatoriamente uno de los TextBox extremos que no esté ocupado
                    Random random = new Random();
                    TextBox textBoxSeleccionado = null;

                    // Intentar encontrar un TextBox no ocupado
                    for (int i = 0; i < fixtureExtremos.Count; i++)
                    {
                        int indice = random.Next(fixtureExtremos.Count);
                        textBoxSeleccionado = fixtureExtremos[indice];

                        // Si el TextBox no está ocupado, lo seleccionamos
                        if (!ocupados.Contains(textBoxSeleccionado))
                        {
                            break;
                        }
                        // Si todos los TextBox están ocupados, mostrar un mensaje
                        if (i == fixtureExtremos.Count - 1)
                        {
                            MessageBox.Show("Todas las posiciones ya estan ocupadas.");
                            return;
                        }
                    }

                    // Asignar el nombre del atleta al TextBox seleccionado
                    textBoxSeleccionado.Text = nombreAtleta;
                    ocupados.Add(textBoxSeleccionado); // Marcar como ocupado
                }
                else
                {
                    MessageBox.Show("Por favor, seleccione un atleta.");
                }
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }
    }
}
