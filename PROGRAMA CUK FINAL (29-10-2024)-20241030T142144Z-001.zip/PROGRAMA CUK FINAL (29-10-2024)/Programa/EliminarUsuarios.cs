﻿using System;
using System.Windows.Forms;

namespace Programa
{
    public partial class EliminarUsuarios : Form
    {
        private GestionUsuarios gestionUsuarios;
        private DataGridView listadoDeUsuarios; // Agregar campo para almacenar el DataGridView

        public EliminarUsuarios(DataGridView listadoDeUsuarios)
        {
            InitializeComponent();

            // Guardar el DataGridView recibido en el campo
            this.listadoDeUsuarios = listadoDeUsuarios;

            // Inicializar la instancia de GestionUsuarios con el DataGridView
            gestionUsuarios = new GestionUsuarios(listadoDeUsuarios);
        }

        private void BTcerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nombre = textBox3.Text;

            // Eliminar el usuario con el nombre proporcionado
            gestionUsuarios.EliminarUsuario(nombre);

            // Actualizar la lista de usuarios en el DataGridView
            gestionUsuarios.ListarUsuarios(listadoDeUsuarios); // Usar el DataGridView correcto
        }

        private void EliminarUsuarios_Load(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
