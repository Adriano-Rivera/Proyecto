﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Programa
{
   public class ConexionDB
    {
       public string connectionString = "Server=localhost;Database=basededatos;Uid=root;Pwd=;";
    }
}
