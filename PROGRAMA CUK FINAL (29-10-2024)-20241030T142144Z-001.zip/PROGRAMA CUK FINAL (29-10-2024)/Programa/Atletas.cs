﻿using System;
using System.Windows.Forms;

namespace Programa
{
    public partial class Atletas : Form
    {
        public Atletas()
        {
            InitializeComponent();
            GestionAtletas gestionAtletas = new GestionAtletas(ListadoDeAtletas);
            gestionAtletas.ListarAtletas();
        }

        private void Atletas_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EliminarAtletas form5 = new EliminarAtletas(ListadoDeAtletas);
            form5.Show();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AgregarAtletas form4 = new AgregarAtletas(ListadoDeAtletas);
            form4.Show();
        }

        private void BTcerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ListadoDeAtletas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ModAtleta_Click(object sender, EventArgs e)
        {
            
            ModificarAtleta form6 = new ModificarAtleta(ListadoDeAtletas);
            form6.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
