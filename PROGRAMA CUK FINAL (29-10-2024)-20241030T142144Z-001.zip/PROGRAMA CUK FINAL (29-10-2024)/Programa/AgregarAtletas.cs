﻿using System;
using System.Windows.Forms;

namespace Programa
{
    public partial class AgregarAtletas : Form
    {
        private GestionAtletas gestionAtletas;

        // Modificar el constructor para recibir el DataGridView
        public AgregarAtletas(DataGridView listadoDeAtletas)
        {
            InitializeComponent();

            // Configurar los ComboBox para que solo permitan seleccionar opciones predefinidas
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;

            // Añadir opciones a los ComboBox
            comboBox1.Items.AddRange(new object[] { "Kumite", "Kata" });
            comboBox2.Items.AddRange(new object[] { "Masculino", "Femenino" });

            // Inicializar GestionAtletas con el DataGridView
            gestionAtletas = new GestionAtletas(listadoDeAtletas);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Obtener los valores de los TextBox y ComboBox
            string nombre = textBox1.Text;       // Nombre
            string apellido = textBox2.Text;     // Apellido
            string ci = textBox3.Text;           // CI (cédula de identidad)
            string sexo = comboBox2.SelectedItem?.ToString(); // Sexo
            string categoria = comboBox1.SelectedItem?.ToString(); // Categoría

            // Verificar si los campos son válidos
            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(apellido) || string.IsNullOrEmpty(ci) ||
                string.IsNullOrEmpty(sexo) || string.IsNullOrEmpty(categoria)) 
            {
                MessageBox.Show("Por favor, completa todos los campos.");
                return;
            }

            // Obtener y convertir los valores de edad y peso
            int edad;
            int peso;
            bool edadValida = int.TryParse(textBox4.Text, out edad); // Convertir edad con validación
            bool pesoValido = int.TryParse(textBox5.Text, out peso); // Convertir peso con validación

            if (!edadValida || !pesoValido)
            {
                MessageBox.Show("Por favor, ingresa valores válidos para edad y peso.");
                return;
            }

            // Llamar al método AgregarAtleta
            gestionAtletas.AgregarAtleta(nombre, apellido, ci, edad, peso, sexo, categoria);

            // Llamar al método ListarAtletas después de agregar un nuevo atleta
            gestionAtletas.ListarAtletas();



        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Nombre
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            // Apellido
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            // CI
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            // Edad
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            // Peso
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Sexo
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Categoría
        }

        private void AgregarAtletas_Load(object sender, EventArgs e)
        {
            // Cualquier código que necesites al cargar el formulario
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
