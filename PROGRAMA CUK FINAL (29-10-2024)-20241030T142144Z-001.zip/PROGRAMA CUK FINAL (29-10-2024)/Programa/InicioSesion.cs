﻿using System;
using MySql.Data.MySqlClient;

namespace Programa
{
    class InicioSesion
    {
        public bool VerificarCredenciales(string nombre, string contraseña)
        {
            bool esValido = false;
            ConexionDB conexionDB = new ConexionDB();
            string connectionString = conexionDB.connectionString;

            using (MySqlConnection conexion = new MySqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();
                    string query = "SELECT COUNT(*) FROM usuario WHERE Nombre = @Nombre AND Contraseña = @Contraseña";
                    using (MySqlCommand comando = new MySqlCommand(query, conexion))
                    {
                        comando.Parameters.AddWithValue("@Nombre", nombre);
                        comando.Parameters.AddWithValue("@Contraseña", contraseña);
                        int count = Convert.ToInt32(comando.ExecuteScalar());

                        if (count > 0)
                        {
                            esValido = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al verificar las credenciales: " + ex.Message);
                }
            }

            return esValido;
        }

        // Método para verificar si el usuario es administrador
        public bool EsAdmin(string nombreUsuario)
        {
            bool esAdmin = false;
            
            ConexionDB conexionDB = new ConexionDB();
            string connectionString = conexionDB.connectionString;

            using (MySqlConnection conexion = new MySqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();
                    string query = "SELECT Rol FROM usuario WHERE Nombre = @Nombre";
                    using (MySqlCommand comando = new MySqlCommand(query, conexion))
                    {
                        comando.Parameters.AddWithValue("@Nombre", nombreUsuario);
                        string rol = Convert.ToString(comando.ExecuteScalar());

                        if (rol == "admin")
                        {
                            esAdmin = true;
                        }
                       
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al verificar el rol: " + ex.Message);
                }
            }

            return esAdmin;
        }
        public bool EsProf(string nombreUsuario)
        {
            bool esProf = false;

            ConexionDB conexionDB = new ConexionDB();
            string connectionString = conexionDB.connectionString;

            using (MySqlConnection conexion = new MySqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();
                    string query = "SELECT Rol FROM usuario WHERE Nombre = @Nombre";
                    using (MySqlCommand comando = new MySqlCommand(query, conexion))
                    {
                        comando.Parameters.AddWithValue("@Nombre", nombreUsuario);
                        string rol = Convert.ToString(comando.ExecuteScalar());

                        if (rol == "profesor")
                        {
                            esProf = true;
                        }

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al verificar el rol: " + ex.Message);
                }
            }

            return esProf;
        }
        public bool EsUser(string nombreUsuario)
        {
            bool esUser = false;

            ConexionDB conexionDB = new ConexionDB();
            string connectionString = conexionDB.connectionString;

            using (MySqlConnection conexion = new MySqlConnection(connectionString))
            {
                try
                {
                    conexion.Open();
                    string query = "SELECT Rol FROM usuario WHERE Nombre = @Nombre";
                    using (MySqlCommand comando = new MySqlCommand(query, conexion))
                    {
                        comando.Parameters.AddWithValue("@Nombre", nombreUsuario);
                        string rol = Convert.ToString(comando.ExecuteScalar());

                        if (rol == "usuario")
                        {
                            esUser = true;
                        }

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al verificar el rol: " + ex.Message);
                }
            }

            return esUser;
        }

    }
}
