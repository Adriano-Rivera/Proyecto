﻿using System;
using System.Windows.Forms;

namespace Programa
{
    public partial class EliminarAtletas : Form
    {
        private GestionAtletas gestionAtletas;

        // Modificar el constructor para recibir el DataGridView
        public EliminarAtletas(DataGridView listadoDeAtletas)
        {
            InitializeComponent();
            gestionAtletas = new GestionAtletas(listadoDeAtletas); // Inicializa con el DataGridView
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            // Este método está vacío, puedes eliminarlo si no lo necesitas.
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ci = textBox3.Text;
            gestionAtletas.EliminarAtleta(ci);
            gestionAtletas.ListarAtletas();
        }

        private void BTcerrar_Click(object sender, EventArgs e)
        {
            // Llamar al método ListarAtletas antes de cerrar el formulario
            
            this.Close();
        }

        private void EliminarAtletas_Load(object sender, EventArgs e)
        {
            // Cualquier código que necesites al cargar el formulario
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
