﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Programa
{
    public partial class ModificarAtleta : Form
    {
        private GestionAtletas gestionAtletas;
        public ModificarAtleta(DataGridView listadoDeAtletas)
        {
            InitializeComponent();
            // Configurar los ComboBox para permitir solo las opciones especificadas
            comboBox2.Items.AddRange(new string[] { "Masculino", "Femenino" });
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;

            comboBox1.Items.AddRange(new string[] { "Kata", "Kumite" });
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            gestionAtletas = new GestionAtletas(listadoDeAtletas);
        }

        private void label4_Click(object sender, EventArgs e)
        {
            // Event handler for label4 click
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //Nombre
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //Apellido
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            //Cedula del atleta a modificar
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            //Edad
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            //Peso
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Sexo
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Categoria
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Captura los valores de los TextBox y ComboBox
            string nombre = textBox1.Text;
            string apellido = textBox2.Text;
            string ci = textBox3.Text;
            string edadStr = textBox4.Text;
            string pesoStr = textBox5.Text;
            string sexo = comboBox2.SelectedItem?.ToString(); // Verificar selección
            string categoria = comboBox1.SelectedItem?.ToString(); // Verificar selección

            // Verificar si todos los campos están rellenados
            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(apellido) || string.IsNullOrEmpty(ci) ||
                string.IsNullOrEmpty(edadStr) || string.IsNullOrEmpty(pesoStr) || sexo == null || categoria == null)
            {
                MessageBox.Show("Rellene todos los campos");
                return;
            }

            // Verificar si Edad y Peso son valores numéricos válidos
            if (!int.TryParse(edadStr, out int edad) || !int.TryParse(pesoStr, out int peso))
            {
                MessageBox.Show("Ingrese valores numéricos válidos para Edad y Peso");
                return;
            }

            // Llamar al método ModificarAtleta de GestionAtletas

            gestionAtletas.ModificarAtleta(nombre, apellido, ci, edad, peso, sexo, categoria);
            gestionAtletas.ListarAtletas();
        }

        private void BTcerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ModificarAtleta_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
