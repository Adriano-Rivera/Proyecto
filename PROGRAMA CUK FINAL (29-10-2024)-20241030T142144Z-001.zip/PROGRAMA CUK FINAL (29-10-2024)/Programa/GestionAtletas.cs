﻿using System;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Data;
using System.Collections.Generic;

namespace Programa
{
    class GestionAtletas
    {

      
        private DataGridView listadoDeAtletas;

        public GestionAtletas(DataGridView dataGridView)
        {
            this.listadoDeAtletas = dataGridView;
           
        }
    
        public GestionAtletas()
        {
        }

        public void ListarAtletas()
        {
            ConexionDB conexionDB = new ConexionDB();
            string connectionString = conexionDB.connectionString;
            string query = "SELECT * FROM atleta";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    listadoDeAtletas.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        public void AgregarAtleta(string nombre, string apellido, string ci, int edad, int peso, string sexo, string categoria)
        {
            ConexionDB conexionDB = new ConexionDB();
            string connectionString = conexionDB.connectionString;
            string query = "INSERT INTO atleta (Nombre, Apellido, CI, Edad, Peso, Sexo, Categoria) VALUES (@Nombre, @Apellido, @CI, @Edad, @Peso, @Sexo, @Categoria)";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@Nombre", nombre);
                    cmd.Parameters.AddWithValue("@Apellido", apellido);
                    cmd.Parameters.AddWithValue("@CI", ci);
                    cmd.Parameters.AddWithValue("@Edad", edad);
                    cmd.Parameters.AddWithValue("@Peso", peso);
                    cmd.Parameters.AddWithValue("@Sexo", sexo);
                    cmd.Parameters.AddWithValue("@Categoria", categoria);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Atleta agregado exitosamente");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        public void EliminarAtleta(string ci)
        {
            ConexionDB conexionDB = new ConexionDB();
            string connectionString = conexionDB.connectionString;
            string query = "DELETE FROM atleta WHERE CI = @CI";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@CI", ci);
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Atleta eliminado exitosamente");
                    }
                    else
                    {
                        MessageBox.Show("No se encontró un atleta con el CI proporcionado");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        public void ModificarAtleta(string nombre, string apellido, string ci, int edad, int peso, string sexo, string categoria)
        {
            if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(apellido) || string.IsNullOrWhiteSpace(ci) ||
                edad <= 0 || peso <= 0 || string.IsNullOrWhiteSpace(sexo) || string.IsNullOrWhiteSpace(categoria))
            {
                MessageBox.Show("Rellene todos los campos");
                return;
            }

            ConexionDB conexionDB = new ConexionDB();
            string connectionString = conexionDB.connectionString;
            string query = "UPDATE atleta SET Nombre = @Nombre, Apellido = @Apellido, Edad = @Edad, Peso = @Peso, Sexo = @Sexo, Categoria = @Categoria WHERE CI = @CI";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@Nombre", nombre);
                    cmd.Parameters.AddWithValue("@Apellido", apellido);
                    cmd.Parameters.AddWithValue("@CI", ci);
                    cmd.Parameters.AddWithValue("@Edad", edad);
                    cmd.Parameters.AddWithValue("@Peso", peso);
                    cmd.Parameters.AddWithValue("@Sexo", sexo);
                    cmd.Parameters.AddWithValue("@Categoria", categoria);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Atleta modificado exitosamente");
                    }
                    else
                    {
                        MessageBox.Show("Atleta no encontrado");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        // Método para buscar un atleta por CI
        public void BuscarAtleta(string ci)
        {
            ConexionDB conexionDB = new ConexionDB();
            string connectionString = conexionDB.connectionString;
            string query = "SELECT * FROM atleta WHERE CI = @CI";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@CI", ci);
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    listadoDeAtletas.DataSource = dataTable;

                    if (dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("No se encontró un atleta con el CI proporcionado");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        public List<string> ObtenerNombresDeAtletas()
        {
            ConexionDB conexionDB = new ConexionDB();
            string connectionString = conexionDB.connectionString;
            string query = "SELECT Nombre FROM atleta";
            List<string> nombresAtletas = new List<string>();

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        nombresAtletas.Add(reader["Nombre"].ToString());
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            return nombresAtletas;
        }
    }
}
