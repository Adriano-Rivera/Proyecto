﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Programa
{
    public partial class Usuarios : Form
    {
        public Usuarios()
        {
            InitializeComponent();
        }

        private void Usuarios_Load(object sender, EventArgs e)
        {
            // Llamar al método ListarUsuarios cuando el formulario cargue
            GestionUsuarios gestionUsuarios = new GestionUsuarios();
            gestionUsuarios.ListarUsuarios(ListadoDeUsuarios);
        }

        private void BTcerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AgrUsuario_Click(object sender, EventArgs e)
        {
            AgregarUsuario form8 = new AgregarUsuario(ListadoDeUsuarios);
            form8.Show();
        }

        private void ModUsuario_Click(object sender, EventArgs e)
        {

           
            ModificarUsuario form9 = new ModificarUsuario(ListadoDeUsuarios);
            form9.Show();
           

        }

        private void EliUsuario_Click(object sender, EventArgs e)
        {
            EliminarUsuarios form10 = new EliminarUsuarios(ListadoDeUsuarios);
            form10.Show();
        }

        private void ListadoDeUsuarios_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
