﻿using System;
using System.Windows.Forms;

namespace Programa
{
    public partial class AgregarUsuario : Form
    {
        private GestionUsuarios gestionUsuarios; // Instancia de GestionUsuarios
        private DataGridView listadoDeUsuarios;  // Agregar referencia al DataGridView

        public AgregarUsuario(DataGridView listadoDeUsuarios)
        {
            InitializeComponent();
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

            // Añadir opciones a los ComboBox
            comboBox1.Items.AddRange(new object[] { "admin", "profesor", "usuario" });

            // Inicializar gestionUsuarios y almacenar listadoDeUsuarios
            this.listadoDeUsuarios = listadoDeUsuarios;
            gestionUsuarios = new GestionUsuarios(listadoDeUsuarios);
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void AgregarUsuario_Load(object sender, EventArgs e)
        {
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void BTcerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Obtener los valores de los TextBox y ComboBox
            string nombre = textBox1.Text;       // Nombre
            string contraseña = textBox2.Text;   // Contraseña
            string rol = comboBox1.Text;         // Rol

            // Verificar si los campos son válidos
            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(contraseña) || string.IsNullOrEmpty(rol))
            {
                MessageBox.Show("Por favor, completa todos los campos.");
                return;
            }

            // Llamar al método AgregarUsuario
            gestionUsuarios.AgregarUsuario(nombre, contraseña, rol);

            // Actualizar la lista de usuarios en el DataGridView
            gestionUsuarios.ListarUsuarios(listadoDeUsuarios); // Pasar el DataGridView
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
