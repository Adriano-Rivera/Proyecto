﻿using System;
using System.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace Programa
{
    class GestionUsuarios
    {
        private DataGridView listadoDeUsuarios;

        public GestionUsuarios(DataGridView dataGridView)
        {
            this.listadoDeUsuarios = dataGridView;
        }

        public GestionUsuarios()
        {
        }




        // Método para listar usuarios en un DataGridView
        public void ListarUsuarios(DataGridView listadoDeUsuarios)
        {
            ConexionDB conexionDB = new ConexionDB();
            string connectionString = conexionDB.connectionString;
            string query = "SELECT * FROM usuario";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    listadoDeUsuarios.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al listar usuarios: " + ex.Message);
                }
            }
        }

        // Método para agregar un usuario a la base de datos
        public void AgregarUsuario(string nombre, string contraseña, string rol)
        {
            ConexionDB conexionDB = new ConexionDB();
            string connectionString = conexionDB.connectionString;
            string query = "INSERT INTO usuario (Nombre, Contraseña, Rol) VALUES (@Nombre, @Contraseña, @Rol)";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@Nombre", nombre);
                    cmd.Parameters.AddWithValue("@Contraseña", contraseña); // Corregido
                    cmd.Parameters.AddWithValue("@Rol", rol);               // Corregido
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Usuario agregado exitosamente");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
        public void ModificarUsuario(string nombre, string contraseña, string rol)
        {
            // Validar si todos los campos están completos
            if (string.IsNullOrWhiteSpace(nombre) || string.IsNullOrWhiteSpace(contraseña) || string.IsNullOrWhiteSpace(rol))
            {
                MessageBox.Show("Rellene todos los campos");
                return;
            }

            ConexionDB conexionDB = new ConexionDB();
            string connectionString = conexionDB.connectionString;
            string query = "UPDATE usuario SET Contraseña = @Contraseña, Rol = @Rol WHERE Nombre = @Nombre";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@Nombre", nombre);
                    cmd.Parameters.AddWithValue("@Contraseña", contraseña);
                    cmd.Parameters.AddWithValue("@Rol", rol);
                 

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Usuario modificado exitosamente");
                    }
                    else
                    {
                        MessageBox.Show("Usuario no encontrado");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
        public void EliminarUsuario(string nombre)
        {
            ConexionDB conexionDB = new ConexionDB();
            string connectionString = conexionDB.connectionString;
            string query = "DELETE FROM usuario WHERE Nombre = @Nombre";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@Nombre", nombre);
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Usuario eliminado exitosamente");
                    }
                    else
                    {
                        MessageBox.Show("No se encontró un Usuario con el Nombre proporcionado");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
    }
}
