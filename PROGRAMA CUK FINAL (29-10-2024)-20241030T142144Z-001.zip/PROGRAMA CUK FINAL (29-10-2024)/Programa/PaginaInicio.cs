﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Programa
{
    public partial class Paginainicio : Form
    {
        private string nombreUsuario; // Almacena el nombre del usuario logueado

        public Paginainicio(string nombreUsuario)
        {
            InitializeComponent();
            this.nombreUsuario = nombreUsuario; // Almacena el nombre del usuario logueado
            LBusuario.Text = nombreUsuario; // Asigna el nombre de usuario a la etiqueta
        }

        private void Paginainicio_Load(object sender, EventArgs e)
        {
        }

        private void LBusuario_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
         

            InicioSesion inicioSesion = new InicioSesion();
            bool esUser = inicioSesion.EsUser(nombreUsuario);

            if (esUser)
            {
                // Mostrar un mensaje de error si no es admin
                MessageBox.Show("No tienes permisos para acceder a esta sección.", "Acceso Denegado", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                MessageBox.Show("Permisos suficientes :)");
                Atletas form3 = new Atletas();
                form3.Show();

            }
        }

        private void BTcerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Verificar si el usuario logueado es admin
            InicioSesion inicioSesion = new InicioSesion();
            bool esAdmin = inicioSesion.EsAdmin(nombreUsuario);

            if (esAdmin)
            {
                // Si es admin, abrir el formulario Usuarios
                MessageBox.Show("Eres administrador");

                Usuarios form7 = new Usuarios();
                form7.Show();
            }
            else
            {
                // Mostrar un mensaje de error si no es admin
                MessageBox.Show("No tienes permisos para acceder a esta sección.", "Acceso Denegado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            InicioSesion inicioSesion = new InicioSesion();
            bool esUser = inicioSesion.EsUser(nombreUsuario);

            if (esUser)
            {
                // Mostrar un mensaje de error si no es admin
                MessageBox.Show("No tienes permisos para acceder a esta sección.", "Acceso Denegado", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                MessageBox.Show("Permisos suficientes :)");
                Torneos form13 = new Torneos(nombreUsuario);
                form13.Show();

            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
    }

