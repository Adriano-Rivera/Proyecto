﻿using System;
using System.Windows.Forms;

namespace Programa
{
    public partial class ModificarUsuario : Form
    {
        private GestionUsuarios gestionUsuarios;
        private DataGridView listadoDeUsuarios; // Agregar referencia al DataGridView

        public ModificarUsuario(DataGridView listadoDeUsuarios)
        {
            InitializeComponent();
            comboBox1.Items.AddRange(new string[] { "admin", "profesor", "usuario" });
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

            // Inicializar gestionUsuarios y almacenar listadoDeUsuarios
            this.listadoDeUsuarios = listadoDeUsuarios;
            gestionUsuarios = new GestionUsuarios(listadoDeUsuarios);
        }
        public static class EstadoFormulario
        {
            public static bool Form1Cerrado { get; set; }
        }
        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void BTcerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //Nombre
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //contraseña
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //rol
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Captura los valores de los TextBox y ComboBox
            string nombre = textBox1.Text;
            string contraseña = textBox2.Text;
            string rol = comboBox1.SelectedItem?.ToString(); // Verificar selección

            // Verificar si todos los campos están rellenados
            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(contraseña) || rol == null)
            {
                MessageBox.Show("Rellene todos los campos");
                return;
            }

            // Llamar al método ModificarUsuario
            gestionUsuarios.ModificarUsuario(nombre, contraseña, rol);

            // Actualizar la lista de usuarios en el DataGridView
            gestionUsuarios.ListarUsuarios(listadoDeUsuarios); // Usar el DataGridView correcto
        }

        private void ModificarUsuario_Load(object sender, EventArgs e)
        {
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            /*Usuarios form7 = new Usuarios();
            form7.Show();*/
            EstadoFormulario.Form1Cerrado = true;
            this.Close();
        }
       
    }
}
