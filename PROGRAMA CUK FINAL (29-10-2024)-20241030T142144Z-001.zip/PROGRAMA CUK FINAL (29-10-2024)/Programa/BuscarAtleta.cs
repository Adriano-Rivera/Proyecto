﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa
{
    public partial class BuscarAtleta : Form
    {
        private GestionAtletas gestionAtletas;

        public BuscarAtleta()
        {
            InitializeComponent();
            gestionAtletas = new GestionAtletas(BuscadoDeAtletas); // Inicializa con el DataGridView
        }

        private void BusAtleta_Click(object sender, EventArgs e)
        {
            string ci = textBox1.Text; // Recoge la cédula del TextBox
            gestionAtletas.BuscarAtleta(ci); // Llama al método BuscarAtleta
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // No se modifica el código original
        }

        private void BTcerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BTlogin_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login form1 = new Login();
            form1.Show();

            
        }

        private void BuscadoDeAtletas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
