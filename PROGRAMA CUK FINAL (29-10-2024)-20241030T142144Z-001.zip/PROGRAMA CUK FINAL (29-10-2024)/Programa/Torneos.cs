﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa
{
    public partial class Torneos : Form
    {
        private string nombreUsuario;
        public Torneos(string nombreUsuario)
        {
            InitializeComponent();
            this.nombreUsuario = nombreUsuario; // Almacena el nombre del usuario logueado
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InicioSesion inicioSesion = new InicioSesion();
            bool esUser = inicioSesion.EsUser(nombreUsuario);

            if (esUser)
            {
                // Mostrar un mensaje de error si no es admin
                MessageBox.Show("No tienes permisos para acceder a esta sección.", "Acceso Denegado", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                MessageBox.Show("Permisos suficientes :)");
                CrearTorneo form12 = new CrearTorneo();
                form12.Show();

            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
