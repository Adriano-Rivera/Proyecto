﻿
namespace Programa
{
    partial class Usuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Usuarios));
            this.ListadoDeUsuarios = new System.Windows.Forms.DataGridView();
            this.ModUsuario = new System.Windows.Forms.Button();
            this.EliUsuario = new System.Windows.Forms.Button();
            this.AgrUsuario = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ListadoDeUsuarios)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // ListadoDeUsuarios
            // 
            this.ListadoDeUsuarios.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            this.ListadoDeUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ListadoDeUsuarios.Location = new System.Drawing.Point(245, 29);
            this.ListadoDeUsuarios.Name = "ListadoDeUsuarios";
            this.ListadoDeUsuarios.Size = new System.Drawing.Size(342, 423);
            this.ListadoDeUsuarios.TabIndex = 1;
            this.ListadoDeUsuarios.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ListadoDeUsuarios_CellContentClick);
            // 
            // ModUsuario
            // 
            this.ModUsuario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(158)))), ((int)(((byte)(213)))));
            this.ModUsuario.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ModUsuario.FlatAppearance.BorderSize = 0;
            this.ModUsuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ModUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ModUsuario.Image = ((System.Drawing.Image)(resources.GetObject("ModUsuario.Image")));
            this.ModUsuario.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ModUsuario.Location = new System.Drawing.Point(-2, 209);
            this.ModUsuario.Name = "ModUsuario";
            this.ModUsuario.Size = new System.Drawing.Size(241, 80);
            this.ModUsuario.TabIndex = 13;
            this.ModUsuario.Text = "Modificar usuario";
            this.ModUsuario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ModUsuario.UseVisualStyleBackColor = false;
            this.ModUsuario.Click += new System.EventHandler(this.ModUsuario_Click);
            // 
            // EliUsuario
            // 
            this.EliUsuario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(158)))), ((int)(((byte)(213)))));
            this.EliUsuario.Cursor = System.Windows.Forms.Cursors.Hand;
            this.EliUsuario.FlatAppearance.BorderSize = 0;
            this.EliUsuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EliUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EliUsuario.Image = ((System.Drawing.Image)(resources.GetObject("EliUsuario.Image")));
            this.EliUsuario.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.EliUsuario.Location = new System.Drawing.Point(-2, 295);
            this.EliUsuario.Name = "EliUsuario";
            this.EliUsuario.Size = new System.Drawing.Size(241, 80);
            this.EliUsuario.TabIndex = 11;
            this.EliUsuario.Text = "Eliminar usuario";
            this.EliUsuario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.EliUsuario.UseVisualStyleBackColor = false;
            this.EliUsuario.Click += new System.EventHandler(this.EliUsuario_Click);
            // 
            // AgrUsuario
            // 
            this.AgrUsuario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(158)))), ((int)(((byte)(213)))));
            this.AgrUsuario.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AgrUsuario.FlatAppearance.BorderSize = 0;
            this.AgrUsuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AgrUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AgrUsuario.Image = ((System.Drawing.Image)(resources.GetObject("AgrUsuario.Image")));
            this.AgrUsuario.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.AgrUsuario.Location = new System.Drawing.Point(-2, 125);
            this.AgrUsuario.Name = "AgrUsuario";
            this.AgrUsuario.Size = new System.Drawing.Size(241, 80);
            this.AgrUsuario.TabIndex = 10;
            this.AgrUsuario.Text = "Agregar usuario";
            this.AgrUsuario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AgrUsuario.UseVisualStyleBackColor = false;
            this.AgrUsuario.Click += new System.EventHandler(this.AgrUsuario_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(158)))), ((int)(((byte)(213)))));
            this.label2.Font = new System.Drawing.Font("BankGothic Md BT", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(238, 36);
            this.label2.TabIndex = 15;
            this.label2.Text = "USUARIOS";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Location = new System.Drawing.Point(-2, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(612, 32);
            this.panel1.TabIndex = 16;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(510, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(22, 26);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 14;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(554, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(23, 26);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Usuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(158)))), ((int)(((byte)(213)))));
            this.ClientSize = new System.Drawing.Size(587, 446);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ModUsuario);
            this.Controls.Add(this.EliUsuario);
            this.Controls.Add(this.AgrUsuario);
            this.Controls.Add(this.ListadoDeUsuarios);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Usuarios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "    ";
            this.Load += new System.EventHandler(this.Usuarios_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ListadoDeUsuarios)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView ListadoDeUsuarios;
        private System.Windows.Forms.Button ModUsuario;
        private System.Windows.Forms.Button EliUsuario;
        private System.Windows.Forms.Button AgrUsuario;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}